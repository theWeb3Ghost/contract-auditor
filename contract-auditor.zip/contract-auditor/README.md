# Contract Auditor — Setup

A tool that pulls verified Solidity source from Etherscan (resolving proxies automatically),
sends it to OpenAI for a security audit, and lets you download the results. Front end is
static; the two API keys live only on Vercel's servers, never in this repo or your browser.

Everything below can be done from a phone browser. No laptop, no command line.

## 1. Push this to GitHub

1. Go to github.com (or the GitHub app) → New repository → e.g. `contract-auditor` → Public is fine (no secrets live in this code).
2. Use "Add file → Upload files" (web) or the GitHub app's upload option, and upload all three files, keeping the folder structure:
   ```
   index.html
   api/etherscan.js
   api/audit.js
   ```
   Important: `etherscan.js` and `audit.js` must be inside a folder literally named `api` at the repo root — Vercel uses that folder name to detect serverless functions.
3. Commit.

## 2. Get your API keys (if you don't have them yet)

- **Etherscan**: etherscan.io → sign in → My Profile → API Keys → create one. It's the same key works across all chains this tool supports (Etherscan's unified V2 API).
- **OpenAI**: platform.openai.com → API keys → create one. Make sure the account has billing set up, or requests will fail.

Keep both somewhere safe — you'll paste them into Vercel next, not into GitHub.

## 3. Deploy on Vercel

1. Go to vercel.com → sign up/log in with your GitHub account.
2. "Add New" → "Project" → select the `contract-auditor` repo → Import.
3. Leave build settings as default (no framework needed) → Deploy.
4. Once deployed, go to the project's **Settings → Environment Variables** and add:
   - `ETHERSCAN_API_KEY` = your Etherscan key
   - `OPENAI_API_KEY` = your OpenAI key
5. Go to **Deployments** → redeploy the latest deployment (env vars only apply after a redeploy).

Your tool is now live at the `*.vercel.app` URL Vercel gives you. Open it on your phone like any website.

## 4. Using it

- Pick a chain, paste one address or a batch (or upload a .txt/.csv list, one address per line).
- Edit the audit prompt if you want to change what it looks for — that's the only field meant to change between runs.
- Run. Unverified contracts are skipped and logged as such. Proxies are resolved to their implementation automatically; if the implementation itself isn't verified, that contract is skipped and flagged rather than silently audited as an empty shell.
- Download results as a single file, or a `.zip` when running a batch.

## Known limitations, so they don't surprise you later

- **Etherscan free tier**: 5 requests/sec, ~100k/day. The tool waits 300ms between contracts to stay under this; a very large batch will just take a while.
- **Context length**: source over ~60,000 characters gets truncated before being sent to the model, and the output will say so. Very large multi-file contracts may need a bigger-context model (edit the model field) or a manual look.
- **Proxy detection**: this relies on Etherscan's own `Proxy`/`Implementation` fields, which cover EIP-1967-style proxies well. Non-standard or custom proxy patterns that Etherscan itself doesn't flag won't be caught, and you'll get an audit of the proxy shell instead of the real logic — worth spot-checking contract behavior against the audit output if something looks off.
- **This is not a substitute for a real audit.** Treat output as a first-pass triage, not a certification.
